package semanticalwaysauthentic.co.listbarang;

public class itembarang {

    private int mId;
    private String mWord;

    public itembarang() {}

    public int getId() {
        return this.mId;
    }

    public String getWord() {
        return this.mWord;
    }

    public void setId(int id) {
        this.mId = id;
    }

    public void setWord(String word) {
        this.mWord = word;
    }
}
